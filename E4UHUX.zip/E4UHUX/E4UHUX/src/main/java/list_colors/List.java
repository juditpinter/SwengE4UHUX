package list_colors; 

import java.util.ArrayList; 

import java.util.NoSuchElementException; 


public class List { 

private ArrayList<String> colors; 

public List() {this.colors = new ArrayList<String>();} 

public void add(String color) {this.colors.add(color);} 

public void remove(String color) 

{ 

int index = this.colors.indexOf(color); 

if(index == -1) throw new NoSuchElementException(); 

this.colors.remove(index); 

} 

public int size() {return this.colors.size();} 

public boolean isEmpty() {return this.colors.isEmpty();} 

public void removeAll() {this.colors.removeAll(colors);} 

} 